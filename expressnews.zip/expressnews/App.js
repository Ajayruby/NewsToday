import React from 'react';
import { StyleSheet } from 'react-native';


import AppNavigator from './src/navigation/AppNavigation';
import {Provider} from 'react-redux';
import store from "./src/store";

export default function App() {

  

  return (
    <Provider store={store}>
    <AppNavigator />
    </Provider>
  );
}

const styles = StyleSheet.create({
});
