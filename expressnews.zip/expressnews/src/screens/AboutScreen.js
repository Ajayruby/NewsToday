import React from 'react';
import { Text, View, StyleSheet } from 'react-native';


const AboutScreen = () => {
    return (
        <View style={styles}>
            <Text>AboutScreen</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    }
})

export default AboutScreen;