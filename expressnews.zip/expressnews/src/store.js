//centrol store for redux

import { createStore, applyMiddleware, combineReducers } from 'redux';

import thunk from 'redux-thunk';
import newsReducer from '../src/redux/reducers/newsReducer';
import { composeWithDevTools } from 'redux-devtools-extension';

const rootReducer = combineReducers({
    news: newsReducer
});//reducer

const middleWare = composeWithDevTools(applyMiddleware(thunk));
export default createStore(rootReducer, middleWare);