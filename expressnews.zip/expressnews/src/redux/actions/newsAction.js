export const FETCH_ARTICLES = 'FETCH_ARTICLES';
export const TOOGLE_FAVORITES = "TOOGLE_FAVORITES";

export const fetchArticles = () => {
    return async dispatch => {
        const result = await fetch('https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=036a86ea419a4477858d16680fb1932a');


        const resultData = await result.json();
        dispatch({
            type: FETCH_ARTICLES,
            payload: resultData

        })



    }
}

export const toogleFavorites = url => {
    return {
        type: TOOGLE_FAVORITES,
        payload: url //id
    }
}