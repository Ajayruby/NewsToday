import { FETCH_ARTICLES, TOOGLE_FAVORITES } from "../actions/newsAction"

const initialState = {

    articles: [],
    favorites: []
}

export default function (state = initialState, action) {

    switch (action.type) {
        case FETCH_ARTICLES:
            return {
                ...state,
                articles: action.payload
            }

        case TOOGLE_FAVORITES:
            const index = state.favorites.findIndex(article => article.url === action.payload);
            if (index >= 0) {
                //favorites existed in articles and add or remove favorites

                const favorites = [...state.favorites];
                favorites.splice(index, 1)//use to remove the favorites
                return {
                    ...state,
                    favorites
                }

            } else {

                //when favorites not existed in list

                const article = state.articles.articles.find(article => article.url === action.payload);// first add the favorites
                return {
                    ...state,
                    favorites: state.favorites.concat(article)
                }
            }
    }
    return state

}